# BrowseMate — AI Side Panel

A Chrome Extension that provides an AI-powered side panel for web browsing, powered by Google Gemini. BrowseMate helps you summarize web pages, answer questions, and maintain conversation context across your browsing sessions.

## Features

- **Persistent Side Panel**: A right-side panel that stays open across tab switches within the same Chrome window
- **AI-Powered Chat**: Chat with Google Gemini about web content and general questions
- **Smart Content Ingestion**: Extract and store webpage content for context-aware conversations
- **Session Management**: Multiple chat sessions with persistent history
- **PDF Support**: Extract text content from PDF documents
- **Query-Aware Context**: Intelligent selection of relevant content snippets based on your questions

## Installation

### From Source (Development)

1. Clone or download this repository
2. Open Chrome and navigate to `chrome://extensions/`
3. Enable "Developer mode" in the top right
4. Click "Load unpacked" and select the `extension` folder
5. Click the BrowseMate extension icon in your toolbar

### Usage

1. **Open the Side Panel**: 
   - Click the BrowseMate extension icon in your Chrome toolbar
   - The side panel will open on the right side of your browser

2. **Set Up Your API Key**:
   - Click the settings gear icon in the panel
   - Enter your Google Gemini API key
   - Click "Test" to verify the key works

3. **Ingest Web Content**:
   - Navigate to any webpage you want to discuss
   - Click "Ingest this web page" in the BrowseMate panel
   - The page content will be extracted and stored for context

4. **Chat with BrowseMate**:
   - Ask questions about the ingested content
   - BrowseMate will use the stored context to provide relevant answers
   - Start new conversations or continue existing ones

## Architecture

### Core Components

- **`panel.html/js/css`**: Main side panel UI and logic
- **`background.js`**: Service worker for side panel initialization
- **`content.js`**: Content script for webpage extraction
- **`gemini.js`**: Gemini API integration and message compilation
- **`storage.js`**: Chrome storage utilities for sessions and settings

### Key Features

- **Content Extraction**: Robust HTML and PDF text extraction
- **Context Management**: Smart selection of relevant content snippets
- **Session Persistence**: Local storage of chat history and ingested content
- **Responsive UI**: Clean, dark theme with proper layout constraints

## Development

### Project Structure

```
extension/
├── panel.html          # Main panel HTML
├── panel.js            # Panel logic and UI interactions
├── panel.css           # Panel styling
├── background.js       # Service worker
├── content.js          # Content script
├── gemini.js           # Gemini API integration
├── storage.js          # Storage utilities
├── manifest.json       # Extension manifest
└── assets/             # Icons and resources
```

### Testing

- **Extension Testing**: Load as unpacked extension in Chrome
- **API Testing**: Use the test button in settings
- **Content Extraction**: Test with various webpage types

### Troubleshooting

1. **Extension Not Loading**:
   - Check Chrome extension page for errors
   - Verify manifest.json syntax
   - Ensure all files are present

2. **API Key Issues**:
   - Verify your Gemini API key is valid
   - Check browser console for error messages
   - Ensure proper permissions are set

3. **Content Extraction Fails**:
   - Check if the page allows content extraction
   - Look for console errors in the target page
   - Try refreshing the page and retrying

4. **Side Panel Not Working**:
   - Ensure Chrome version supports side panel API
   - Check if extension has proper permissions
   - Try disabling and re-enabling the extension

## Security

- **Local Storage**: All data is stored locally in your browser
- **No Data Collection**: No user data is sent to external servers
- **API Key Security**: Your Gemini API key is stored locally and only used for API calls
- **Content Privacy**: Webpage content is processed locally before being sent to Gemini

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License

MIT License - see LICENSE file for details

## Support

- **Issues**: Report bugs and feature requests via GitHub issues
- **Documentation**: Check the README and code comments
- **Community**: Join discussions in the repository

---

**BrowseMate** - Your AI-powered browsing companion! 🚀
